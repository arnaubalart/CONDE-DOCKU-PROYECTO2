# CONDE-DOCKU21
## Trabajo realizado por: David Ortega, Ivan Aguinaga, Arnau Balart

### IMPORTANTE crear el archivo config.php dentro de services y que contenga (con los datos de vuestro host de base de datos):

```
 define("SERVIDOR","localhost");
 define("USUARIO","root");
 define("PASSWORD","");
 define("BD","bd_restaurant");
```

### Para acceder:
##### Hay dos tipos de usuarios:
- David, Arnau, Ivan (inicial en mayúsculas) --> Camareros
- Danny (inicial en mayúsculas) --> Mantenimiento
##### Contraseñas:
- David: qweQWE123
- Arnau: asdASD123
- Ivan: zxcZXC123
- Danny: admin123
